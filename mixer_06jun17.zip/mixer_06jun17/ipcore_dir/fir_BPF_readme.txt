The following files were generated for 'fir_BPF' in directory
C:\Xilinx\Projects\mixer_06jun17\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * fir_BPF.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * fir_BPF.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * fir_BPF.ngc
   * fir_BPF.v
   * fir_BPF.veo
   * fir_BPFCOEFF_auto0_0.mif
   * fir_BPFfilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * fir_BPF.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * fir_BPF.asy
   * fir_BPF.mif

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * fir_BPF_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * fir_BPF.gise
   * fir_BPF.xise

Deliver Readme:
   Readme file for the IP.

   * fir_BPF_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * fir_BPF_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

